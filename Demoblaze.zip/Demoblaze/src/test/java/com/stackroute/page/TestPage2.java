package com.stackroute.page;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class TestPage2 {
	
	private static WebDriver driver = null;
	
	@BeforeClass
	public static void setup() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	                               // purchase page
	@Test 
	public void test07() {
		//purchase page 
		  driver.get("https://www.demoblaze.com/cart.html"); 
		  driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.MINUTES);
		  driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		  	  
		    driver.findElement(By.xpath("/html/body/div[6]/div/div[2]/button")).click();
	    	driver.findElement(By.id("name")).sendKeys("raju");
			driver.findElement(By.id("country")).sendKeys("India");
			driver.findElement(By.id("city")).sendKeys("Hyderabad");
			driver.findElement(By.id("card")).sendKeys("5359 4568 7894");
			driver.findElement(By.id("month")).sendKeys("june");
			driver.findElement(By.id("year")).sendKeys("2022");
			driver.findElement(By.xpath("/html/body/div[3]/div/div/div[3]/button[2]")).click();
			driver.findElement(By.xpath("/html/body/div[3]/div/div/div[3]/button[1]")).click();
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		  String expectedTitle = "STORE";
		  String actualTitle = driver.getTitle();
		  Assert.assertEquals(expectedTitle, actualTitle,"purchase page  is not available");
		    }
		
	                                     // Log in page
	@Test
	public void test08() {
	driver.get("https://www.demoblaze.com"); 
               //	leave username fields Empty and click in Login button
	driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.MINUTES);
	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	
	driver.findElement(By.id("login2")).click();
	driver.findElement(By.id("loginusername")).sendKeys("");
	driver.findElement(By.id("loginpassword")).sendKeys("abcd123");
	driver.findElement(By.xpath("/html/body/div[3]/div/div/div[3]/button[2]")).click();
	Alert alert = driver.switchTo().alert();
	alert.accept();
	
	String expectedTitle = "STORE";
	String actualTitle = driver.getTitle();
	Assert.assertEquals(expectedTitle, actualTitle,"Alert message appears ,Please fill out Username and Password");
    }
	
	@Test
	public void test09(){
	driver.get("https://www.demoblaze.com"); 
	            //Enter a valid username , Enter an invalid password
	driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.MINUTES);
	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	
	driver.findElement(By.id("login2")).click();
	driver.findElement(By.id("loginusername")).sendKeys("@bcd123");
	driver.findElement(By.id("loginpassword")).sendKeys("123");
	driver.findElement(By.xpath("/html/body/div[3]/div/div/div[3]/button[2]")).click();

	String expectedTitle = "STORE";
	String actualTitle = driver.getTitle();
	Assert.assertEquals(expectedTitle, actualTitle,"Alert message appears , User does not exist");
    }
  
	@Test
	public void test10() {
	driver.get("https://www.demoblaze.com"); 
	            //Enter a valid username , Enter an valid password
	driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.MINUTES);
	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	
	driver.findElement(By.id("login2")).click();
	driver.findElement(By.id("loginusername")).sendKeys("@bcd123");
	driver.findElement(By.id("loginpassword")).sendKeys("abcd123");
	driver.findElement(By.xpath("/html/body/div[3]/div/div/div[3]/button[2]")).click();
	
	String expectedTitle = "STORE";
	String actualTitle = driver.getTitle();
	Assert.assertEquals(expectedTitle, actualTitle,"Demoblaze Login page not available");
    }
  
	@Test
	public void test11() {
		                            //logout
		driver.get("https://www.demoblaze.com");
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.MINUTES);
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("/html/body/nav/div[1]/ul/li[2]/a")).click();
	
		String expectedTitle = "STORE";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle,"Demoblaze logout page is not available");
	    }
		 

@AfterClass
public static void windup() {
driver.close();
}


}
