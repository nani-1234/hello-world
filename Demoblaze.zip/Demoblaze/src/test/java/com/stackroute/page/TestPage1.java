package com.stackroute.page ;
 	import java.util.concurrent.TimeUnit;
	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.testng.Assert;
	import org.testng.annotations.AfterClass;
	import org.testng.annotations.BeforeClass;
	import org.testng.annotations.Test;
	import io.github.bonigarcia.wdm.WebDriverManager;

		public class TestPage1 {
			
			private static WebDriver driver = null;
				
			@BeforeClass
				public static void setup() {
					WebDriverManager.chromedriver().setup();
					driver = new ChromeDriver();
					driver.manage().window().maximize();
				}
				
			                               //Home page 
			
			@Test
			public void test01() {
		                    	// Slide right and left arrow
			driver.get("https://www.demoblaze.com"); 
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			
			driver.findElement(By.xpath("/html/body/nav/div[2]/div/a[1]")).click();
			driver.navigate().refresh();
			driver.findElement(By.xpath("/html/body/nav/div[2]/div/a[2]")).click();
			
			String expectedTitle = "STORE";
			String actualTitle = driver.getTitle();
					
			Assert.assertEquals(expectedTitle, actualTitle,"Store page is not available");	
		    }
			
			@Test
			public void test02() {
			                        	//phone page 
				driver.get("https://www.demoblaze.com"); 
				driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.MINUTES);
				driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
				
				driver.findElement(By.xpath("/html/body/div[5]/div/div[1]/div/a[2]")).click();
				
				String expectedTitle = "STORE";
				String actualTitle = driver.getTitle();
				Assert.assertEquals(expectedTitle, actualTitle,"Demoblaze Phone page is not available");
		    }
			
			@Test
			public void test03(){
			                     	//Samsung galaxy s6 page 
				driver.get("https://www.demoblaze.com");  
				driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
					
				driver.findElement(By.xpath("/html/body/div[5]/div/div[2]/div/div[1]/div/div/h4/a")).click();
				
				String expectedMessage = "Samsung galaxy s6";
				String actualMessage = driver.findElement(By.className("name")).getText();
				Assert.assertEquals(expectedMessage, actualMessage,"Samsung galaxy s6 page is not available");
		    }
			
			@Test
			public void test04(){
				                              //Contact page
				driver.get("https://www.demoblaze.com"); 
				driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.MINUTES);
				driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
					
				driver.findElement(By.xpath("/html/body/nav/div[1]/ul/li[2]/a")).click();
				driver.findElement(By.id("recipient-email")).sendKeys("raju157@gmail.com");
				driver.findElement(By.id("recipient-name")).sendKeys("raju");
				driver.findElement(By.id("message-text")).sendKeys("product query");
				
				driver.findElement(By.xpath("/html/body/div[1]/div/div/div[3]/button[1]")).click();
				
				String expectedMessage = "New message";
				String actualMessage = driver.findElement(By.id("exampleModalLabel")).getText();
				Assert.assertEquals(expectedMessage, actualMessage,"Contact page is not available");
			}
			
			@Test
			public void test05(){
				                             //About us page 
				driver.get("https://www.demoblaze.com"); 
				driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.MINUTES);
				driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
					
				driver.findElement(By.xpath("/html/body/nav/div[1]/ul/li[3]/a")).click();
				driver.findElement(By.xpath("/html/body/div[4]/div/div/div[3]/button")).click();
				
				String expectedMessage = "About us";
				String actualMessage = driver.findElement(By.id("videoModalLabel")).getText();
				Assert.assertEquals(expectedMessage, actualMessage,"About us  page is not available");
		    }
			
			@Test
			public void test06() {
				                             //CATEGORIES Page 
				driver.get("https://www.demoblaze.com"); 
				driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.MINUTES);
				driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
					
				driver.findElement(By.xpath("/html/body/div[5]/div/div[1]/div/a[1]")).click();
				
				String expectedMessage = "CATEGORIES";
				String actualMessage = driver.findElement(By.id("cat")).getText();
				Assert.assertEquals(expectedMessage, actualMessage,"Categories page is not available");
		    }

			@AfterClass
			public static void windup() {
			driver.close();
			}
	}		
