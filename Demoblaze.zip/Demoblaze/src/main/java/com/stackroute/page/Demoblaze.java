package com.stackroute.page;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Demoblaze {
	private WebDriver webDriver = null;
	
	@FindBy (name= "email")
	private WebElement email;
	
	@FindBy (name= "password")
	private WebElement password;
	
	@FindBy (name= "acceptTos")
	private WebElement accept;
	
	@FindBy (xpath= "/html/body/div[2]/div/div/div[3]/button[2]")
	private WebElement signUp;
	
	@FindBy (xpath= "//div[@class='Form__error']//span")
	private WebElement fieldIsRequired;
	
	@FindBy (xpath= "//div[@class='Form__error']//span")
	private WebElement fieldchecked;
	
	@FindBy (xpath= "/html/body/div/div/div[1]/div/div[3]/div/div/div[2]/form/div[2]/div/div[1]/div/div/span")
	private WebElement emailNotValid;
	
	@FindBy (xpath= "/html/body/nav/div[1]/ul/li[5]/a")
	private WebElement login;
	
	@FindBy (xpath= "/html/body/div[3]/div/div/div[3]/button[2]")
	private WebElement loginButtonn;
	
	

	
	public Demoblaze() {
	}


	public Demoblaze(WebDriver webDriver, WebElement tryItNowFreeButton, WebElement firstName,WebElement lastName,WebElement email,WebElement company,WebElement password,WebElement fieldIsRequired,WebElement accept,WebElement fieldchecked,WebElement emailNotValid,WebElement loginButtonn,WebElement login) {
		super();
		this.webDriver = webDriver;
		this.email=email;
		this.password=password;
		this.fieldIsRequired=password;
		this.accept=accept;
		this.fieldchecked=fieldchecked;
		this.emailNotValid=emailNotValid;
		this.login=login;
		this.loginButtonn=loginButtonn;
		
		PageFactory.initElements(webDriver,this);
	}
	
	public Demoblaze(WebDriver webDriver) {
		this.webDriver = webDriver;
	
		PageFactory.initElements(webDriver, this);
	}
	

	public String getTitle() {
		return webDriver.getTitle();
	}
	
	public void email(String email) {
		this.email.sendKeys(email);
	}
	
	public void password(String password) {
		this.password.sendKeys(password);
	}
	public void signUp() {
		this.signUp.click();
	}
	public void login() {
		this.login.click();
	}
	public void accept() {
		this.accept.click();
	}
	public String loginButtonn() {
		return this.loginButtonn.getText();
	}
	public String fieldIsRequired() {
		return this.fieldIsRequired.getText();
	}
	public String fieldchecked() {
		return this.fieldchecked.getText();
	}
	public String emailNotValid() {
		return this.emailNotValid.getText();
	}
	
	public void maximizeBrowser() {
		webDriver.manage().window().maximize();
	}
	public void refresh() {
		webDriver.navigate().refresh();
	}
	public void close() {
		webDriver.close();
	}
	
	public void quitPage() {
		webDriver.quit();
	}

	
	
	
}
